package com.hemnath.springdemo.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Controller;

import com.sun.istack.internal.logging.Logger;

@Aspect
@Controller
public class CRMLoggingAspect {
	
	// Setup Logger
	private Logger myLogger = Logger.getLogger(getClass().getName(), null);
	
	// Setup Point Cut Expression
	@Pointcut("execution(* com.hemnath.springdemo.controller.*.*(..))")
	private void forControllerPackage() {}
	
	// Add Point Cut expressions for Service and DAO
	@Pointcut("execution(* com.hemnath.springdemo.dao.*.*(..))")
	private void forDAOPackage() {}
	
	@Pointcut("execution(* com.hemnath.springdemo.service.*.*(..))")
	private void forServicePackage() {}
	
	@Pointcut("forControllerPackage() || forDAOPackage() || forServicePackage()")
	private void forAppFlow() {}
	
	// @Before Advice
	@Before("forAppFlow()")
	public void before(JoinPoint theJoinPoint) {
		
		String theMethod = theJoinPoint.getSignature().toShortString();
		myLogger.info("===> in @Before: calling Method" + theMethod);
		
		// Display the Arguments to the method
		
		// Get the Arguments
		Object args[] = theJoinPoint.getArgs();
		
		for(Object arg : args) {
			myLogger.info("===> Arguments: " + arg);
		}
		
	}
	
	@AfterReturning(
			pointcut = "forAppFlow()",
			returning = "theResult")
	public void afterReturning(JoinPoint theJoinPoint, Object theResult){
		
		// Display the method we are returning
		String theMethod = theJoinPoint.getSignature().toShortString();
		myLogger.info("===> in @AfterReturning: calling Method" + theMethod);
		
		// Display the data returned
		myLogger.info("==> the result: " + theResult);
	}
	
	

}
